const tabsMain = document.querySelectorAll('.btn-main');
const tabsSidebar = document.querySelectorAll('.btn-sidebar');

const tabMainClicked = (tabMain) => {
    tabsMain.forEach(tab => tab.classList.remove('active'));
    tabMain.classList.add('active');

    const contents = document.querySelectorAll('.content');
    contents.forEach(content => content.classList.remove('show'));

    const contentId = tabMain.getAttribute('content-id');
    const content = document.getElementById(contentId);
    if (content) {
        content.classList.add('show');
    }
};

const tabSidebarClicked = (tabSidebar) => {
    tabsSidebar.forEach(tabSidebar => tabSidebar.classList.remove('active'));
    tabSidebar.classList.add('active');

    const contents = document.querySelectorAll('.content');
    contents.forEach(content => content.classList.remove('show'));

    const contentId = tabSidebar.getAttribute('content-id');
    const content = document.getElementById(contentId);
    if (content) {
        content.classList.add('show');
    }
};

tabsMain.forEach(tabMain => tabMain.addEventListener('click', () => tabMainClicked(tabMain)));
tabsSidebar.forEach(tabSidebar => tabSidebar.addEventListener('click', () => tabSidebarClicked(tabSidebar)));
tabsConfig.forEach(tabConfig => tabConfig.addEventListener('click', () => tabConfigClicked(tabConfig)));

document.querySelectorAll("textarea").forEach(function(textarea) {
    textarea.style.height = textarea.scrollHeight + "px";
    textarea.style.overflowY = "hidden";
  
    textarea.addEventListener("input", function() {
      this.style.height = "auto";
      this.style.height = this.scrollHeight + "px";
    });
});