const btnLogin = document.querySelector('.btn-login');
const btnCreate = document.querySelector('.btn-create');
const modal = document.querySelector('.modal');
const modalOut = document.querySelector('.modal-out');
const modalLogin = document.querySelector('.modal-login');
const modalCreate = document.querySelector('.modal-create');

btnLogin.addEventListener('click', () => {
    modal.style.display = 'flex';
    modalLogin.style.display = 'flex';
    modalCreate.style.display = 'none';
});

btnCreate.addEventListener('click', () => {
    modal.style.display = 'flex';
    modalLogin.style.display = 'none';
    modalCreate.style.display = 'flex';
});

modalOut.addEventListener('click', () => {
    modal.style.display = 'none';
    modalLogin.style.display = 'none';
    modalCreate.style.display = 'none';
});

document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        modal.style.display = 'none';
        modalLogin.style.display = 'none';
        modalCreate.style.display = 'none';
    }
});

document.addEventListener('click', (event) => {
    if (event.target === modal) {
        modal.style.display = 'none';
        modalLogin.style.display = 'none';
        modalCreate.style.display = 'none';
    }
});

document.getElementById('toggleLoginPassword').addEventListener('click', function() {
    this.classList.toggle('active');
});

document.getElementById('toggleCreatePassword').addEventListener('click', function() {
    this.classList.toggle('active');
});

function togglePasswordVisibility(...fields) {
    fields.forEach(function(fieldId) {
        var field = document.getElementById(fieldId);
        if (field) {
            field.type = field.type === "password" ? "text" : "password";
        }
    });
}

function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("login-password").value;

    var errorMessageLogin = document.querySelector(".modal-login span");

    if (!username || !password) {
        displayMessage(errorMessageLogin, "Por favor, preencha todos os campos.", "error");
        return;
    }

    if (username === "admin" && password === "1234") {
        location.href = "public/home.html";
    } else {
        displayMessage(errorMessageLogin, "Usuário ou senha inválidos.", "error");
    }
}

function createAccount() {
    var name = document.getElementById("name").value.trim();
    var email = document.getElementById("email").value.trim();
    var password = document.getElementById("create-password").value;
    var confirmPassword = document.getElementById("create-confirmpassword").value;

    var errorMessageCreate = document.querySelector(".modal-create span");

    if (!name || !email || !password || !confirmPassword) {
        displayMessage(errorMessageCreate, "Por favor, preencha todos os campos.", "error");
        return;
    }

    if (!validateEmail(email)) {
        displayMessage(errorMessageCreate, "Por favor, insira um e-mail válido.", "error");
        return;
    }

    if (password !== confirmPassword) {
        displayMessage(errorMessageCreate, "As senhas não coincidem.", "error");
        return;
    }

    displayMessage(errorMessageCreate, "", "success");
    errorMessageCreate.style.visibility = "hidden";

    location.href = "pages/home.html";
}

function displayMessage(container, message, type) {
    container.innerHTML = message;
    container.className = `message ${type}`;
    container.style.visibility = "visible";
}

function validateEmail(email) {
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}